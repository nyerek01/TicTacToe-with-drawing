package example;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Example extends JFrame implements ActionListener, MouseListener{

    static Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    static byte fields[][];
    
    byte rows, columns, lineNumbers;
    short sizeXO, coordX, coordY, stepNumbers, top, bottom, left, right, screenWidth,screenHeight, windowWidth, windowHeight,drawAreaX,drawAreaY,a,a2,b,b2,modX,modY;
    boolean nextStepIsX, win;
    JPanel pn;
    JMenuBar mb;
    JMenu mFile, mHelp;
    JMenuItem miNewGame, miExit, miAbout;
    
    public Example() {

        pn = new JPanel();
        mb = new JMenuBar();
        
        mFile = new JMenu("File");
        mb.add(mFile);
        
        miNewGame = new JMenuItem("New Game");
        miExit    = new JMenuItem("Exit");
        
        mFile.add(miNewGame);
        mFile.add(miExit);
        
        setJMenuBar(mb);
        
        rows        = 0    ;
        columns     = 0    ;
        lineNumbers = 3    ;
        sizeXO      = 0    ;
        coordX      = 0    ;
        coordY      = 0    ;
        stepNumbers = 0    ;
        nextStepIsX = true ;
        win         = false;
        fields      = new byte[lineNumbers+4][lineNumbers+4];
        for (byte i = 0; i < fields.length; i++) {
            for (byte j = 0; j < fields.length; j++) {
                fields[i][j] = 0;//0 jelenti az ureset, 1 az X-et, 2 a O-t
            }
        }
        screenWidth  = (short) screenSize.width ;
        screenHeight = (short) screenSize.height;
        windowWidth  = 608;
        windowHeight = 631;
        
        setLocation((screenWidth-windowWidth)/2, (screenHeight-windowHeight)/2);
        addMouseListener(this);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setVisible(true   );
        
        top       = (short) getInsets().top    ;
        left      = (short) getInsets().left   ;
        right     = (short) getInsets().right  ;
        bottom    = (short) getInsets().bottom ;

        if ((windowHeight-top-bottom)!=(windowWidth-left-right)) {
            windowWidth=(short) (windowHeight-top-bottom+left+right);
            setLocation((screenWidth-windowWidth)/2, (screenHeight-windowHeight)/2);
        }
        drawAreaX  = (short) (windowWidth-left-right );
        drawAreaY  = (short) (windowHeight-top-bottom);
        
        a          = (short) (drawAreaX/lineNumbers  );
        modX       = (short) (drawAreaX%lineNumbers  );
        a2         = (short) (left-a                 );
        b          = (short) (drawAreaY/lineNumbers  );
        modY       = (short) (drawAreaY%lineNumbers  );
        b2         = (short) (top-b                  );
        
        sizeXO     = (short) ((drawAreaX>>2)+drawAreaX/lineNumbers>>2);
        
        setSize(drawAreaX%lineNumbers==0?++windowWidth:windowWidth, drawAreaY%lineNumbers==0?++windowHeight:windowHeight);
        
    }

    public static void main(String[] args) {
        new Example();
        
    }
    
    @Override
    public void paint (Graphics g) {
        /*      SNAKE

        Kezdesnek lehetne rajzolni egy keretet, amihez ha hozza er a kigyo, akkor vege a jateknak.
        Ez menubol lehet allitani, hogy legyen keret vagy ne legyen, checkbox kattintasaval.
        Ha nincs keret akkor a palya szelenek utkozve a szemkozti oldalon jon ki, vegtelenitett palya.
        Lehetne labirintus szeru palya, de legalabbis nem egy sima keret.
        Veletlenszeruen megjeleno kaja, eloszor egy helyben allna, majd lenne olyan is ami mozog (kigyonal lassabban).
        Lehetne akar tobb kigyo is, akar tobb jatekos, vagy gepi mesterseges intelligencia.
        A kigyo(k) tudnanak szaporodni, akar osztodassal is, egy bizonyos meret felett kette tudna valni.
        Masik mod, hogy ket kigyo letre tudna hozni egy harmadikat, mondjuk ugy hogy a ket szulo merete csokkene.
        */
        
        /*      GOMOKU
        
        A vonalak altal hatarolt negyzetekbe lehet majd rajzolni, jatekosnak megfeleloen X vagy O szimbolumot (vagy egyebet).
        Kell egy Timer osztalyu objektum, vele szamoltatjuk a jatekidot.
        Aktualis allas szamontartasa, pl.: 3-1, az eredmenyhez tartozo pont(ozasi)rendszer kidolgosasa.
        Adatbazis, de legalabb file szintu (XML) perzisztens adattarolas.
        Mesterseges Intelligencia megfelelo programozasa, 3x3-as esetben verhetetlen legyen, egyebkent nincs specifikalva.
        A gepnek legyen valaszthato tudasszintje, akar randomtol kezdve a tokeletes strategia megvalositasaig.
        Lehessen valasztani szimbolumot (X,O, stb.), kezdolepest, legyen lehetoseg lepes visszavonasara.
        Tudjon egymas ellen jatszani gep-gep, ember-ember, es ember-gep.
        */
    Graphics2D g2 = (Graphics2D) g;
    
    for (byte i = 0; i <= lineNumbers; i++) {
        g2.drawLine(a2+=a, top, a2, windowHeight-bottom-modX-1);
        g2.drawLine(left, b2+=b, windowWidth-right-modY-1, b2 );
    }
}
    @Override
    public void mouseReleased(MouseEvent e) {
        boolean x = true, y = true;
        for (byte i = 0; i < lineNumbers && (x || y); i++) {
                if (e.getX() < (left + drawAreaX) * (i + 1) / lineNumbers && x) {
                    x = false;
                    columns = i;
                    coordX = (short) (((drawAreaX) * (i + 1) / lineNumbers + left) - ((drawAreaX) / lineNumbers) / 2);
                }
                if (e.getY() < (top + drawAreaY) * (i + 1) / lineNumbers && y) {
                    y = false;
                    rows = i;
                    coordY = (short) (((drawAreaY) * (i + 1) / lineNumbers + top) - ((drawAreaY) / lineNumbers) / 2);
                }
        }
        if (fields[rows+2][columns+2]==0) {
            System.out.println("fields["+(rows+1)+"]["+(columns+1)+"]==0");
            draw(coordX,coordY);
        }
    }
    public void draw(int x, int y){
        Graphics g = this.getGraphics();
        if (nextStepIsX) {
            g.setColor(Color.RED);
            g.drawOval(x-sizeXO/2, y-sizeXO/2, sizeXO, sizeXO);
        }else{
            g.drawLine(x-sizeXO/2, y-sizeXO/2, x+sizeXO/2, y+sizeXO/2);
            g.drawLine(x-sizeXO/2, y+sizeXO-sizeXO/2, x+sizeXO/2, y-sizeXO/2);
        }
        fields[rows+2][columns+2]=(byte) ((nextStepIsX)?2:1);
        for (int i = 2; i < fields.length-2; i++) {
            for (int j = 2; j < fields.length-2; j++) {
                System.out.print("fields: "+fields[i][j]+", ");
            }
        }
        System.out.println("");
        nextStepIsX=!nextStepIsX;
        if (++stepNumbers>2) {
            winCheck();
//            System.out.println("stepNumbers = "+stepNumbers);
        }
    }
    void winCheck(){
        for (byte i = 2; i < 5 && !win; i++) {
            for (int j = 2; j < 5 && !win; j++) {
//                System.out.println("field i = "+i+", j = "+j+": "+fields[i][j]);
                if (fields[i][j]!=0 && (fields[i][j]==fields[i-1][j-1] && fields[i][j]==fields[i+1][j+1] || fields[i][j]==fields[i-1][j] && fields[i][j]==fields[i+1][j] || fields[i][j]==fields[i][j-1] && fields[i][j]==fields[i][j+1])) {
                    System.out.println("Win");
                    win = true;
                }
            }
        }
    }
    @Override
    public void actionPerformed(ActionEvent e) {
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

}
