package example;

import static example.Simbol.*;

public class Converter {

    static void Convert() {
        drawSimbol(Example.graphics, sizeSimbol, sizeSimbol);
    }
}
